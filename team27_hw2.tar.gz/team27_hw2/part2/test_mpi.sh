mpiexec -np 2 ./mpi -n $1 
